# EMMZY JAMB CBT

An offline-first Android Studio starter app for JAMB preparation.

## Included
- Native Android app built with Kotlin and Jetpack Compose
- English, Mathematics, Economics and Accounting categories
- Practice mode with subject and question-count selection
- Timed mock/practice sessions, A-D options, navigation and scoring
- Explanations and source labels after submission
- Local question bank persistence
- JSON question-bank import
- Optional online JSON download/sync URL
- Basic progress tracking (attempt count, latest and best percentage)

## Important content note
The included questions are original practice examples, not verified official JAMB past questions. No complete official JAMB archive is bundled. Add only questions you have permission to use and can verify. The app's `year` and `source` fields let you label verified items accurately.

## Open and build
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle to sync.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press Run.

The generated project is source code, not a precompiled APK. Android Studio/Gradle is required to compile and sign an installable APK.

## JSON import format
Use `sample_questions.json` as a template. The top-level object must contain a `questions` array.

Each question:
- `id`: unique identifier
- `subject`: English, Mathematics, Economics, or Accounting
- `year`: e.g. `2024` or `Practice`
- `topic`: topic name
- `question`: question text
- `options`: exactly A, B, C, D
- `answer`: A, B, C, or D
- `explanation`: short explanation
- `source`: e.g. `Original practice question` or a properly verified source label

## Online sync
Open Settings in the app and paste a trusted HTTPS URL that returns the same JSON format. The app downloads and merges those questions into its local bank. It keeps previously stored questions available offline. This is a simple read-only download endpoint, not a hosted account/database service.

## Current limitations / next development steps
- The mock selects up to 180 questions from the currently loaded bank. To simulate a full JAMB session, load a sufficiently large bank.
- Progress currently stores attempts, best percentage and latest percentage locally; detailed per-question history and charts can be added.
- The current mock draws randomly from the loaded bank; a future version can enforce the intended JAMB subject distribution and exam-specific rules.
- No automatic official past-question scraping is included.

## Phone-only cloud APK build

This project includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.
After uploading the project files to a GitHub repository, open the repository in a browser, select **Actions**, choose **Build EMMZY JAMB CBT APK**, tap **Run workflow**, and wait for the build to finish. Open the completed run and download the `EMMZY-JAMB-CBT-APK` artifact. GitHub may require you to sign in and verify your account. This cloud build has not yet been run or verified.
