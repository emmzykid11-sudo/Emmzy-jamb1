package com.emmzy.jambcbt

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.random.Random

data class Question(
    val id: String,
    val subject: String,
    val year: String,
    val topic: String,
    val prompt: String,
    val options: Map<String, String>,
    val answer: String,
    val explanation: String,
    val source: String
)

private val subjects = listOf("English", "Mathematics", "Economics", "Accounting")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EmmzyApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmmzyApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("emmzy_cbT", Context.MODE_PRIVATE) }
    var bank by remember { mutableStateOf(loadBank(context)) }
    var screen by remember { mutableStateOf("Home") }
    var selectedSubject by remember { mutableStateOf("All subjects") }
    var session by remember { mutableStateOf<List<Question>>(emptyList()) }
    var answers by remember { mutableStateOf(mapOf<Int, String>()) }
    var current by remember { mutableIntStateOf(0) }
    var secondsLeft by remember { mutableIntStateOf(2 * 60 * 60) }
    var submitted by remember { mutableStateOf(false) }
    var sessionTitle by remember { mutableStateOf("JAMB Practice") }
    var urlText by remember { mutableStateOf(prefs.getString("bank_url", "") ?: "") }
    var status by remember { mutableStateOf("Offline question bank ready") }
    var showSettings by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val text = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                            ?: error("Could not read selected file")
                    }
                    val added = parseQuestions(text)
                    bank = (bank.filterNot { old -> added.any { it.id == old.id } } + added)
                    saveBank(context, bank)
                    status = "Imported ${added.size} questions successfully"
                } catch (e: Exception) {
                    status = "Import failed: ${e.message}"
                }
            }
        }
    }

    LaunchedEffect(screen, submitted) {
        while (screen == "Exam" && !submitted && secondsLeft > 0) {
            delay(1000)
            secondsLeft--
        }
        if (screen == "Exam" && secondsLeft == 0 && !submitted) submitted = true
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF123B70),
        secondary = androidx.compose.ui.graphics.Color(0xFF0A8F82)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("EMMZY JAMB CBT", fontWeight = FontWeight.Bold) },
                    actions = {
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Practice", "Progress", "Question bank").forEach { item ->
                        NavigationBarItem(
                            selected = screen == item,
                            onClick = { if (screen != "Exam") screen = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Home" -> Icons.Default.Home
                                        "Practice" -> Icons.Default.Edit
                                        "Progress" -> Icons.Default.BarChart
                                        else -> Icons.Default.LibraryBooks
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            when (screen) {
                "Home" -> HomeScreen(bank.size, status, onStart = {
                    startExam(bank, "All subjects", "JAMB-style mock", onReady = { q ->
                        session = q; answers = emptyMap(); current = 0
                        secondsLeft = 2 * 60 * 60; submitted = false
                        sessionTitle = "JAMB-style mock"; screen = "Exam"
                    }, onError = { status = it })
                }, onPractice = { screen = "Practice" })
                "Practice" -> PracticeScreen(bank, selectedSubject, { selectedSubject = it }) { subject, count ->
                    val pool = if (subject == "All subjects") bank else bank.filter { it.subject.equals(subject, true) }
                    if (pool.isEmpty()) status = "No questions for $subject yet. Import a question bank."
                    else {
                        session = pool.shuffled().take(count.coerceAtMost(pool.size))
                        answers = emptyMap(); current = 0; secondsLeft = 60 * 60
                        submitted = false; sessionTitle = "$subject practice"; screen = "Exam"
                    }
                }
                "Progress" -> ProgressScreen(context, bank.size)
                "Question bank" -> BankScreen(bank, status, onImport = {
                    importLauncher.launch(arrayOf("application/json", "text/plain"))
                }, onClear = {
                    bank = sampleQuestions()
                    saveBank(context, bank)
                    status = "Restored built-in sample bank"
                })
                "Exam" -> ExamScreen(
                    session, answers, current, secondsLeft, submitted,
                    onAnswer = { idx, value -> answers = answers + (idx to value) },
                    onMove = { current = it.coerceIn(0, (session.size - 1).coerceAtLeast(0)) },
                    onSubmit = {
                        submitted = true
                        saveResult(context, session.size, session.indices.count { answers[it] == session[it].answer })
                    },
                    onHome = { screen = "Home" },
                    title = sessionTitle
                )
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Question bank settings") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Optional online JSON question-bank URL")
                        OutlinedTextField(
                            value = urlText, onValueChange = { urlText = it },
                            label = { Text("https://example.com/questions.json") },
                            singleLine = true
                        )
                        Text("Online sync requires a trusted HTTPS URL serving the EMMZY JSON format. Imported questions remain available offline.")
                        Text(status, style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        prefs.edit().putString("bank_url", urlText.trim()).apply()
                        showSettings = false
                        scope.launch {
                            if (urlText.isNotBlank()) {
                                status = "Downloading question bank..."
                                try {
                                    val text = withContext(Dispatchers.IO) {
                                        val conn = URL(urlText.trim()).openConnection() as HttpURLConnection
                                        conn.connectTimeout = 10000; conn.readTimeout = 15000
                                        conn.inputStream.bufferedReader().use { it.readText() }.also { conn.disconnect() }
                                    }
                                    val downloaded = parseQuestions(text)
                                    bank = (bank.filterNot { old -> downloaded.any { it.id == old.id } } + downloaded)
                                    saveBank(context, bank)
                                    status = "Synced ${downloaded.size} online questions"
                                } catch (e: Exception) { status = "Online sync failed: ${e.message}" }
                            } else status = "No online URL set; offline bank remains ready"
                        }
                    }) { Text("Save and sync") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
fun HomeScreen(total: Int, status: String, onStart: () -> Unit, onPractice: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("YOUR 300+ JOURNEY STARTS HERE", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                Text("Study smart. Practise daily. Improve every score.", color = MaterialTheme.colorScheme.onPrimary)
                Text("$total questions loaded", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge)
            }
        }
        Text("Choose a subject", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        subjects.forEach { SubjectCard(it) }
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(52.dp)) { Icon(Icons.Default.Timer, null); Spacer(Modifier.width(8.dp)); Text("Start JAMB-style mock exam") }
        OutlinedButton(onClick = onPractice, modifier = Modifier.fillMaxWidth()) { Text("Practise by subject") }
        Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
        Text("Note: Built-in items are original practice questions, not claimed as official JAMB past questions.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SubjectCard(subject: String) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MenuBook, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Text(subject, fontWeight = FontWeight.SemiBold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PracticeScreen(bank: List<Question>, selected: String, onSubject: (String) -> Unit, onStart: (String, Int) -> Unit) {
    var count by remember { mutableIntStateOf(10) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Practice mode", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Select a subject and question count.")
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
            OutlinedTextField(selected, { }, readOnly = true, label = { Text("Subject") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                (listOf("All subjects") + subjects).forEach { item ->
                    DropdownMenuItem(text = { Text(item) }, onClick = { onSubject(item); expanded = false })
                }
            }
        }
        Text("Number of questions: $count")
        Slider(value = count.toFloat(), onValueChange = { count = it.toInt() }, valueRange = 5f..60f, steps = 10)
        Text("Available in selection: ${if (selected == "All subjects") bank.size else bank.count { it.subject.equals(selected, true) }}")
        Button(onClick = { onStart(selected, count) }, modifier = Modifier.fillMaxWidth()) { Text("Start practice") }
    }
}

@Composable
fun ExamScreen(
    questions: List<Question>, answers: Map<Int, String>, current: Int, seconds: Int,
    submitted: Boolean, onAnswer: (Int, String) -> Unit, onMove: (Int) -> Unit,
    onSubmit: () -> Unit, onHome: () -> Unit, title: String
) {
    if (questions.isEmpty()) { Text("No questions loaded."); return }
    val q = questions[current.coerceIn(0, questions.lastIndex)]
    val score = questions.indices.count { answers[it] == questions[it].answer }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontWeight = FontWeight.Bold)
            Text("%02d:%02d".format(seconds / 3600, (seconds % 3600) / 60), color = if (seconds < 300) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(progress = { (current + 1).toFloat() / questions.size }, modifier = Modifier.fillMaxWidth())
        Text("Question ${current + 1} of ${questions.size}  •  ${q.subject}", style = MaterialTheme.typography.labelLarge)
        if (submitted) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Result: $score / ${questions.size}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Score: ${if (questions.isEmpty()) 0 else score * 100 / questions.size}%")
                }
            }
        }
        Text(q.prompt, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        q.options.toSortedMap().forEach { (key, value) ->
            val chosen = answers[current] == key
            val isCorrect = q.answer == key
            Card(
                onClick = { if (!submitted) onAnswer(current, key) },
                colors = CardDefaults.cardColors(
                    containerColor = when {
                        submitted && isCorrect -> MaterialTheme.colorScheme.secondaryContainer
                        chosen -> MaterialTheme.colorScheme.primaryContainer
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = chosen, onClick = { if (!submitted) onAnswer(current, key) }, enabled = !submitted)
                    Text("$key. $value")
                }
            }
        }
        if (submitted) {
            Text("Answer: ${q.answer}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
            Text(q.explanation)
            Text("Source: ${q.source}", style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = { onMove(current - 1) }, enabled = current > 0) { Text("Previous") }
            OutlinedButton(onClick = { onMove(current + 1) }, enabled = current < questions.lastIndex) { Text("Next") }
        }
        if (!submitted) Button(onClick = onSubmit, modifier = Modifier.fillMaxWidth()) { Text("Submit examination") }
        else Button(onClick = onHome, modifier = Modifier.fillMaxWidth()) { Text("Finish and return home") }
    }
}

@Composable
fun ProgressScreen(context: Context, total: Int) {
    val prefs = remember { context.getSharedPreferences("emmzy_cbT", Context.MODE_PRIVATE) }
    val attempts = prefs.getInt("attempts", 0)
    val best = prefs.getInt("best", 0)
    val latest = prefs.getInt("latest", 0)
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Your progress", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        StatCard("Completed attempts", attempts.toString())
        StatCard("Best score", "$best%")
        StatCard("Latest score", "$latest%")
        StatCard("Question bank", "$total questions")
        Text("Keep practising consistently. Your best and latest percentages are saved on this phone.")
    }
}

@Composable
fun StatCard(label: String, value: String) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label); Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun BankScreen(bank: List<Question>, status: String, onImport: () -> Unit, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Question bank", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("${bank.size} questions stored on this device")
        subjects.forEach { s -> Text("$s: ${bank.count { it.subject.equals(s, true) }}") }
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(8.dp)); Text("Import JSON question bank") }
        OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) { Text("Restore built-in sample questions") }
        Text(status, style = MaterialTheme.typography.bodySmall)
        Text("Use the sample_questions.json file in the project as your import template.")
    }
}

fun startExam(bank: List<Question>, subject: String, title: String, onReady: (List<Question>) -> Unit, onError: (String) -> Unit) {
    if (bank.isEmpty()) onError("Question bank is empty. Import questions first.")
    else onReady(bank.shuffled().take(180))
}

fun saveResult(context: Context, total: Int, correct: Int) {
    val p = context.getSharedPreferences("emmzy_cbT", Context.MODE_PRIVATE)
    val pct = if (total == 0) 0 else correct * 100 / total
    p.edit().putInt("attempts", p.getInt("attempts", 0) + 1)
        .putInt("latest", pct).putInt("best", maxOf(p.getInt("best", 0), pct)).apply()
}

fun loadBank(context: Context): List<Question> {
    val saved = context.getSharedPreferences("emmzy_cbT", Context.MODE_PRIVATE).getString("bank_json", null)
    if (saved != null) return try { parseQuestions(saved) } catch (_: Exception) { sampleQuestions() }
    return try {
        val raw = context.assets.open("sample_questions.json").bufferedReader().use { it.readText() }
        parseQuestions(raw)
    } catch (_: Exception) { sampleQuestions() }
}

fun saveBank(context: Context, bank: List<Question>) {
    val arr = JSONArray()
    bank.forEach { q ->
        val opts = JSONObject(); q.options.forEach { (k, v) -> opts.put(k, v) }
        arr.put(JSONObject().put("id", q.id).put("subject", q.subject).put("year", q.year)
            .put("topic", q.topic).put("question", q.prompt).put("options", opts)
            .put("answer", q.answer).put("explanation", q.explanation).put("source", q.source))
    }
    context.getSharedPreferences("emmzy_cbT", Context.MODE_PRIVATE).edit().putString("bank_json", JSONObject().put("questions", arr).toString()).apply()
}

fun parseQuestions(raw: String): List<Question> {
    val root = JSONObject(raw)
    val arr = root.optJSONArray("questions") ?: JSONArray()
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val optsObj = o.getJSONObject("options")
        val opts = listOf("A", "B", "C", "D").associateWith { optsObj.optString(it) }.filterValues { it.isNotBlank() }
        require(opts.size == 4) { "Question ${i + 1} must have A, B, C and D options" }
        val answer = o.getString("answer").uppercase()
        require(answer in listOf("A", "B", "C", "D")) { "Invalid answer key in question ${i + 1}" }
        Question(
            o.optString("id", "imported-$i"), o.getString("subject"), o.optString("year", "Practice"),
            o.optString("topic", "General"), o.getString("question"), opts, answer,
            o.optString("explanation", "Review the topic and check the correct option."),
            o.optString("source", "Imported practice")
        )
    }
}

fun sampleQuestions(): List<Question> {
    val raw = """{
      "questions": [
        {"id":"eng001","subject":"English","year":"Practice","topic":"Grammar","question":"Choose the correct option: Neither the teacher nor the students ___ present.","options":{"A":"was","B":"were","C":"is","D":"has"},"answer":"B","explanation":"With neither...nor, the verb agrees with the nearer subject. Students is plural, so 'were' is used.","source":"Original practice question"},
        {"id":"eng002","subject":"English","year":"Practice","topic":"Vocabulary","question":"Choose the word nearest in meaning to 'brief'.","options":{"A":"lengthy","B":"concise","C":"unclear","D":"ordinary"},"answer":"B","explanation":"'Concise' means brief and expressed in few words.","source":"Original practice question"},
        {"id":"eng003","subject":"English","year":"Practice","topic":"Parts of speech","question":"In the sentence 'She spoke softly', the word 'softly' is a/an ___.","options":{"A":"adjective","B":"noun","C":"adverb","D":"pronoun"},"answer":"C","explanation":"'Softly' modifies the verb 'spoke', so it is an adverb.","source":"Original practice question"},
        {"id":"eng004","subject":"English","year":"Practice","topic":"Concord","question":"Choose the correct sentence.","options":{"A":"He don't like rice.","B":"He doesn't likes rice.","C":"He doesn't like rice.","D":"He not like rice."},"answer":"C","explanation":"After 'doesn't', use the base form of the verb: like.","source":"Original practice question"},
        {"id":"eng005","subject":"English","year":"Practice","topic":"Prepositions","question":"The meeting starts ___ 9 o'clock.","options":{"A":"in","B":"on","C":"at","D":"by"},"answer":"C","explanation":"'At' is used with a specific clock time.","source":"Original practice question"},
        {"id":"mat001","subject":"Mathematics","year":"Practice","topic":"Percentages","question":"Find 15% of 800.","options":{"A":"100","B":"110","C":"120","D":"140"},"answer":"C","explanation":"15/100 × 800 = 120.","source":"Original practice question"},
        {"id":"mat002","subject":"Mathematics","year":"Practice","topic":"Algebra","question":"Solve 3x + 5 = 20.","options":{"A":"3","B":"5","C":"6","D":"8"},"answer":"B","explanation":"3x = 20 − 5 = 15; therefore x = 5.","source":"Original practice question"},
        {"id":"mat003","subject":"Mathematics","year":"Practice","topic":"Ratio","question":"Divide ₦600 in the ratio 2:3. What is the smaller share?","options":{"A":"₦200","B":"₦240","C":"₦300","D":"₦360"},"answer":"B","explanation":"Total parts = 5. Smaller share = 2/5 × 600 = ₦240.","source":"Original practice question"},
        {"id":"mat004","subject":"Mathematics","year":"Practice","topic":"Simple interest","question":"Find the simple interest on ₦2,000 at 5% per annum for 3 years.","options":{"A":"₦200","B":"₦250","C":"₦300","D":"₦350"},"answer":"C","explanation":"I = PRT/100 = 2000 × 5 × 3 / 100 = ₦300.","source":"Original practice question"},
        {"id":"mat005","subject":"Mathematics","year":"Practice","topic":"Linear equations","question":"If 2x − 7 = 9, find x.","options":{"A":"6","B":"7","C":"8","D":"9"},"answer":"C","explanation":"2x = 16, so x = 8.","source":"Original practice question"},
        {"id":"eco001","subject":"Economics","year":"Practice","topic":"Demand","question":"The law of demand states that, other things being equal, quantity demanded generally ___ as price rises.","options":{"A":"increases","B":"decreases","C":"remains fixed","D":"doubles"},"answer":"B","explanation":"The law of demand describes an inverse relationship between price and quantity demanded, all else equal.","source":"Original practice question"},
        {"id":"eco002","subject":"Economics","year":"Practice","topic":"Inflation","question":"A persistent rise in the general price level is known as ___.","options":{"A":"deflation","B":"devaluation","C":"inflation","D":"recession"},"answer":"C","explanation":"Inflation is a sustained increase in the general price level.","source":"Original practice question"},
        {"id":"eco003","subject":"Economics","year":"Practice","topic":"Factors of production","question":"Which factor of production earns wages?","options":{"A":"Land","B":"Labour","C":"Capital","D":"Entrepreneurship"},"answer":"B","explanation":"Labour receives wages or salaries as its factor reward.","source":"Original practice question"},
        {"id":"eco004","subject":"Economics","year":"Practice","topic":"Opportunity cost","question":"The next best alternative forgone when a choice is made is called ___.","options":{"A":"marginal utility","B":"opportunity cost","C":"fixed cost","D":"total revenue"},"answer":"B","explanation":"Opportunity cost is the value of the next best alternative sacrificed.","source":"Original practice question"},
        {"id":"eco005","subject":"Economics","year":"Practice","topic":"Market","question":"A market with many buyers and many sellers dealing in a homogeneous product is closest to ___.","options":{"A":"monopoly","B":"oligopoly","C":"perfect competition","D":"monopsony"},"answer":"C","explanation":"Perfect competition is characterised by many buyers and sellers and a homogeneous product.","source":"Original practice question"},
        {"id":"acc001","subject":"Accounting","year":"Practice","topic":"Accounting equation","question":"Which of the following is the correct accounting equation?","options":{"A":"Assets = Capital − Liabilities","B":"Assets = Liabilities + Capital","C":"Capital = Assets + Liabilities","D":"Liabilities = Assets + Capital"},"answer":"B","explanation":"The accounting equation is Assets = Capital (or Equity) + Liabilities.","source":"Original practice question"},
        {"id":"acc002","subject":"Accounting","year":"Practice","topic":"Books of original entry","question":"A cash book records ___.","options":{"A":"only credit purchases","B":"cash and bank transactions","C":"only depreciation","D":"only sales returns"},"answer":"B","explanation":"A cash book records receipts and payments through cash and bank.","source":"Original practice question"},
        {"id":"acc003","subject":"Accounting","year":"Practice","topic":"Trial balance","question":"The main purpose of a trial balance is to check the arithmetical accuracy of ___.","options":{"A":"ledger balances","B":"bank statements","C":"invoices","D":"source documents"},"answer":"A","explanation":"A trial balance lists ledger balances to check whether total debits equal total credits.","source":"Original practice question"},
        {"id":"acc004","subject":"Accounting","year":"Practice","topic":"Depreciation","question":"Depreciation is the allocation of the depreciable amount of a non-current asset over its ___.","options":{"A":"purchase day","B":"useful life","C":"selling price","D":"invoice number"},"answer":"B","explanation":"Depreciation allocates an asset's depreciable amount over its useful life.","source":"Original practice question"},
        {"id":"acc005","subject":"Accounting","year":"Practice","topic":"Double entry","question":"When a business receives cash from a customer for a previous credit sale, which account is debited?","options":{"A":"Sales account","B":"Customer's account","C":"Cash account","D":"Purchases account"},"answer":"C","explanation":"Cash increases, so the cash account is debited; the customer's receivable is credited.","source":"Original practice question"}
      ]
    }"""
    return parseQuestions(raw)
